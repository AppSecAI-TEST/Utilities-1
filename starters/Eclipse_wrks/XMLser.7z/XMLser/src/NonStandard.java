
public class NonStandard {
 public int field = 0;
 
 public void fieldSet(int set) {
	 field = set;
 }
 
 public int fieldGet(){
	 return field;
 }
 
}
