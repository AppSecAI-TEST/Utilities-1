

public class NPair {
  NonStandard ns = null;
  int number1 = 0;
  int number2 = 0;
  public void setNs(NonStandard ns) { this.ns=ns; }
  public NonStandard getNs() { return ns; }
  public void setNumber1(int value) { number1 = value; }
  public int getNumber1() { return number1; }
  public void setNumber2(int value) { number2 = value; }
  public int getNumber2() { return number2; }
}