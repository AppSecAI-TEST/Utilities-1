package reflection_samples;

public class MyException extends Exception {}
