package junit_test;

public class MySimpleCalc {
	public int add (int op1, int op2)
	{
		return op1 + op2;
	}
	public int substr (int op1, int op2)
	{
		return op1 - op2;
	}
	public int mult (int op1, int op2)
	{
		return op1 * op2;
	}
	public int div (int op1, int op2)
	{
		return op1 / op2;
	}
}
